# Down.io (Android)

Kotlin + Jetpack Compose. Tarama/indirme motoru: yt-dlp (youtubedl-android) + ffmpeg.

## APK nasıl alınır
**A) Android Studio:** klasörü aç → Gradle sync → Build > Build APK(s) → `app/build/outputs/apk/debug/app-debug.apk`
**B) GitHub (bilgisayarsız):** klasörü yeni bir repoya yükle → Actions > "Build APK" > Run workflow → Artifacts > `Down.io-apk`

APK'yı telefona at, "bilinmeyen kaynaklardan yükleme"ye izin ver, kur.

## Notlar
- minSdk 29 (Android 10+), yalnızca arm64-v8a (app/build.gradle.kts içinde değiştirilebilir)
- Siteler sık değiştiği için yt-dlp kütüphane sürümü (`0.17.2`) zamanla eskir; indirme bozulursa build.gradle.kts'te güncel sürüme çek.
- Spotify (DRM korumalı) desteklenmez.
