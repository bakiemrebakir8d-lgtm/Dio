package io.down.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem as ExoItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.size.Size
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val Blue = Color(0xFF0071E3)   // tek vurgu rengi (beyaz üzerinde 4.8:1)
val Sans = FontFamily.SansSerif

// ───────────── Tema ─────────────
@Composable
fun DownTheme(content: @Composable () -> Unit) {
    val dark = when (Prefs.theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val cs = if (dark) darkColorScheme(
        primary = Color(0xFF4DA3FF), background = Color.Black, surface = Color(0xFF1C1C1E),
        onBackground = Color.White, onSurface = Color.White,
        surfaceVariant = Color(0xFF2C2C2E), onSurfaceVariant = Color(0xFFAEAEB2), error = Color(0xFFFF8A80),
    ) else lightColorScheme(
        primary = Blue, background = Color(0xFFF2F2F7), surface = Color.White,
        onBackground = Color(0xFF1C1C1E), onSurface = Color(0xFF1C1C1E),
        surfaceVariant = Color(0xFFE9E9EE), onSurfaceVariant = Color(0xFF63636A), error = Color(0xFFC62828),
    )
    val ty = Typography(
        bodyLarge = TextStyle(fontFamily = Sans, fontSize = 17.sp),
        bodyMedium = TextStyle(fontFamily = Sans, fontSize = 15.sp),
        labelSmall = TextStyle(fontFamily = Sans, fontSize = 12.sp),
    )
    MaterialTheme(colorScheme = cs, typography = ty, content = content)
}

// ───────────── Bileşenler ─────────────
@Composable fun rememberTap(): () -> Unit {
    val h = LocalHapticFeedback.current
    return { if (Prefs.haptic) h.performHapticFeedback(HapticFeedbackType.LongPress) }
}

fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

@Composable fun Logo(size: Int = 96) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape((size * 0.27f).dp))
            .background(Brush.linearGradient(listOf(Color(0xFF3D9BFF), Blue))),
        contentAlignment = Alignment.Center,
    ) { Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.fillMaxSize()) }
}

@Composable fun LargeTitle(t: String, sub: String? = null) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
        Text(t, fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp, fontFamily = Sans)
        if (sub != null) Text(sub, fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier, shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp) {
        Column(content = content)
    }
}

@Composable fun Primary(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick, modifier.heightIn(min = 50.dp), enabled = enabled, shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Color.White)) {
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable fun Secondary(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FilledTonalButton(onClick, modifier.heightIn(min = 50.dp), shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.filledTonalButtonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurface)) {
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val tap = rememberTap()
    Box(
        Modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(22.dp))
            .background(if (selected) Blue else MaterialTheme.colorScheme.surfaceVariant)
            .clickable { tap(); onClick() }.padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.Medium,
            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface)
    }
}

@Composable fun PillRow(options: List<Pair<String, String>>, current: String, onSelect: (String) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { (k, label) -> Pill(label, k == current) { onSelect(k) } }
    }
}

@Composable fun SmallLabel(t: String) =
    Text(t, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 20.dp, top = 12.dp, bottom = 4.dp))

fun iconFor(t: MType): ImageVector = when (t) {
    MType.VIDEO -> Icons.Rounded.VideoFile; MType.IMAGE -> Icons.Rounded.Image
    MType.AUDIO -> Icons.Rounded.AudioFile; else -> Icons.Rounded.Description
}

@Composable fun Thumb(m: Media) {
    val ctx = LocalContext.current
    Box(Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        Icon(iconFor(m.type), null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        if (m.thumb != null) AsyncImage(
            model = ImageRequest.Builder(ctx).data(m.thumb).apply { m.headers.forEach { (k, v) -> addHeader(k, v) } }.crossfade(true).build(),
            contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
        )
    }
}

// ───────────── Açılış ─────────────
@Composable fun Splash(onDone: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    var go by remember { mutableStateOf(false) }
    val a by animateFloatAsState(if (go) 1f else 0f, tween(700), label = "a")
    LaunchedEffect(Unit) {
        go = true
        coroutineScope { launch { delay(1300) }; Engine.init(ctx) }
        onDone()
    }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
        Column(Modifier.graphicsLayer { alpha = a; scaleX = 0.9f + 0.1f * a; scaleY = 0.9f + 0.1f * a }, horizontalAlignment = Alignment.CenterHorizontally) {
            Logo(96)
            Spacer(Modifier.height(20.dp))
            Text("Down.io", fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp)
            Spacer(Modifier.height(28.dp))
            CircularProgressIndicator(Modifier.size(28.dp), color = Blue, strokeWidth = 3.dp)
        }
    }
}

// ───────────── Kök ─────────────
@Composable fun Root(vm: AppVM) {
    var splash by remember { mutableStateOf(true) }
    if (splash) { Splash { splash = false }; return }
    val tap = rememberTap()
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (vm.tab) { 0 -> HomeScreen(vm); 1 -> HistoryScreen(vm); 2 -> SettingsScreen(vm); else -> AboutScreen() }
        }
        Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 12.dp) {
            Row(Modifier.fillMaxWidth()) {
                listOf("İndir" to Icons.Rounded.Download, "Geçmiş" to Icons.Rounded.History,
                    "Ayarlar" to Icons.Rounded.Settings, "Hakkında" to Icons.Rounded.Info).forEachIndexed { i, (label, icon) ->
                    val sel = vm.tab == i
                    val c = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    Column(Modifier.weight(1f).heightIn(min = 56.dp).clickable { tap(); vm.tab = i }.padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Icon(icon, label, tint = c)
                        Text(label, fontSize = 12.sp, color = c, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
            }
        }
    }
    vm.preview?.let { PreviewDialog(it) { vm.preview = null } }
    if (vm.showBulk) BulkDialog(vm)
    if (vm.showTutorial) TutorialDialog { vm.showTutorial = false; Prefs.tutorialSeen = true; Prefs.save() }
}

// ───────────── İndir ekranı ─────────────
@Composable fun HomeScreen(vm: AppVM) {
    val clip = LocalClipboardManager.current
    val tap = rememberTap()
    val shown = vm.shown()
    val sub = MaterialTheme.colorScheme.onSurfaceVariant
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { LargeTitle("Down.io", "Bağlantıyı yapıştır. Medyayı bul.") }
        item {
            Glass(Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextField(
                        value = vm.link, onValueChange = { vm.link = it }, singleLine = true,
                        placeholder = { Text("https://…") }, shape = RoundedCornerShape(14.dp),
                        colors = fieldColors(), modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { if (vm.link.isNotBlank()) vm.scan(listOf(vm.link)) }),
                        trailingIcon = {
                            Row {
                                if (vm.link.isNotEmpty()) IconButton({ vm.link = "" }) { Icon(Icons.Rounded.Close, "Temizle") }
                                IconButton({ clip.getText()?.text?.let { vm.link = it.trim() } }) { Icon(Icons.Rounded.ContentPaste, "Yapıştır") }
                            }
                        },
                    )
                    if (vm.error?.contains("ifre") == true) TextField(
                        value = vm.password, onValueChange = { vm.password = it }, singleLine = true,
                        placeholder = { Text("Klasör şifresi") }, shape = RoundedCornerShape(14.dp),
                        colors = fieldColors(), modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Primary("Tara", Modifier.weight(1f), enabled = !vm.scanning && vm.link.isNotBlank()) { tap(); vm.scan(listOf(vm.link)) }
                        Secondary("Toplu") { vm.showBulk = true }
                    }
                }
            }
        }
        if (vm.scanning) item {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Blue, strokeWidth = 2.5.dp)
                Spacer(Modifier.width(12.dp)); Text("Taranıyor", color = sub)
            }
        }
        vm.error?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) } }
        if (vm.items.isNotEmpty()) {
            item {
                Column {
                    SmallLabel("Filtre")
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { Pill("Tümü (${vm.items.size})", vm.filter == null) { vm.filter = null } }
                        items(MType.values().filter { t -> vm.items.any { it.type == t } }) { t ->
                            Pill("${t.label} (${vm.items.count { it.type == t }})", vm.filter == t) { vm.filter = t }
                        }
                    }
                    SmallLabel("Sırala")
                    PillRow(listOf("name" to "Ad", "size" to "Boyut", "type" to "Tür"), vm.sort) { vm.sort = it }
                    SmallLabel("Video kalitesi")
                    PillRow(listOf("best" to "En iyi", "1080" to "1080p", "720" to "720p", "480" to "480p", "audio" to "Yalnız ses"), vm.quality) { vm.quality = it }
                    Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${vm.selected.size} seçili", color = sub, modifier = Modifier.weight(1f))
                        val all = shown.isNotEmpty() && shown.all { it.id in vm.selected }
                        TextButton({
                            if (all) shown.forEach { vm.selected.remove(it.id) } else shown.forEach { if (it.id !in vm.selected) vm.selected.add(it.id) }
                        }, Modifier.heightIn(min = 44.dp)) { Text(if (all) "Seçimi kaldır" else "Tümünü seç") }
                    }
                    Primary("İndir (${vm.selected.size})", Modifier.padding(horizontal = 16.dp).fillMaxWidth(), enabled = vm.selected.isNotEmpty()) { tap(); vm.downloadSelected() }
                    Spacer(Modifier.height(8.dp))
                }
            }
            items(shown, key = { it.id }) { m ->
                ItemRow(m, m.id in vm.selected, vm.tasks[m.id],
                    onToggle = { if (m.id in vm.selected) vm.selected.remove(m.id) else vm.selected.add(m.id) },
                    onOpen = { vm.preview = m }, onCancel = { vm.cancel(m) })
            }
        }
    }
}

@Composable fun fieldColors() = TextFieldDefaults.colors(
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, disabledIndicatorColor = Color.Transparent,
    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant, unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
)

@Composable fun ItemRow(m: Media, checked: Boolean, task: DownloadState?, onToggle: () -> Unit, onOpen: () -> Unit, onCancel: () -> Unit) {
    val sub = MaterialTheme.colorScheme.onSurfaceVariant
    Glass(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(Modifier.clickable(onClick = onOpen).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Thumb(m)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(m.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text("${m.type.label} · ${m.ext.uppercase().ifBlank { "—" }} · ${fmtSize(m.size)}", fontSize = 13.sp, color = sub)
                when (task?.status) {
                    DS.Done -> Text("İndirildi", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                    DS.Failed -> Text(task.error ?: "Hata", fontSize = 13.sp, color = MaterialTheme.colorScheme.error, maxLines = 2)
                    DS.Canceled -> Text("İptal edildi", fontSize = 13.sp, color = sub)
                    DS.Queued -> Text("Sırada", fontSize = 13.sp, color = sub)
                    else -> {}
                }
            }
            if (task?.status == DS.Running || task?.status == DS.Queued) IconButton(onCancel) { Icon(Icons.Rounded.Close, "İptal") }
            else Checkbox(checked, { onToggle() })
        }
        if (task?.status == DS.Running) LinearProgressIndicator(progress = { task.progress }, modifier = Modifier.fillMaxWidth(), color = Blue)
    }
}

// ───────────── Önizleme ─────────────
@Composable fun PreviewDialog(m: Media, onClose: () -> Unit) {
    val ctx = LocalContext.current
    Dialog(onClose, DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val url = m.previewUrl
            when {
                url != null && m.type == MType.IMAGE -> {
                    var scale by remember { mutableFloatStateOf(1f) }
                    var off by remember { mutableStateOf(Offset.Zero) }
                    AsyncImage(
                        model = ImageRequest.Builder(ctx).data(url).size(Size.ORIGINAL).apply { m.headers.forEach { (k, v) -> addHeader(k, v) } }.build(),
                        contentDescription = m.title, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                            .pointerInput(Unit) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    scale = (scale * zoom).coerceIn(1f, 6f)
                                    off = if (scale == 1f) Offset.Zero else off + pan
                                }
                            }
                            .graphicsLayer(scaleX = scale, scaleY = scale, translationX = off.x, translationY = off.y),
                    )
                }
                url != null && (m.type == MType.VIDEO || m.type == MType.AUDIO) -> VideoPlayer(url, m.headers)
                else -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                    Icon(iconFor(m.type), null, tint = Color.White, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Bu tür için önizleme yok", color = Color.White)
                }
            }
            Box(Modifier.align(Alignment.TopStart).systemBarsPadding().padding(8.dp).clip(RoundedCornerShape(24.dp)).background(Color(0x99000000))) {
                IconButton(onClose) { Icon(Icons.Rounded.Close, "Kapat", tint = Color.White) }
            }
            Text("${m.title} · ${fmtSize(m.size)}", color = Color.White, fontSize = 15.sp, maxLines = 2,
                modifier = Modifier.align(Alignment.BottomStart).systemBarsPadding().padding(start = 16.dp, end = 16.dp, bottom = 72.dp))
        }
    }
}

@Composable fun VideoPlayer(url: String, headers: Map<String, String>) {
    val ctx = LocalContext.current
    val player = remember(url) {
        val ds = DefaultHttpDataSource.Factory().setUserAgent(Net.UA).setAllowCrossProtocolRedirects(true).setDefaultRequestProperties(headers)
        ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build().apply {
            setMediaItem(ExoItem.fromUri(url)); prepare(); playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxSize())
}

// ───────────── Diyaloglar ─────────────
@Composable fun BulkDialog(vm: AppVM) {
    var txt by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { vm.showBulk = false },
        title = { Text("Toplu tarama", fontWeight = FontWeight.Bold) },
        text = { TextField(txt, { txt = it }, Modifier.fillMaxWidth(), placeholder = { Text("Her satıra bir bağlantı") }, minLines = 5, colors = fieldColors(), shape = RoundedCornerShape(14.dp)) },
        confirmButton = {
            TextButton({
                val l = txt.lines().map { it.trim() }.filter { it.isNotBlank() }
                if (l.isNotEmpty()) { vm.showBulk = false; vm.tab = 0; vm.scan(l) }
            }, Modifier.heightIn(min = 44.dp)) { Text("Tara") }
        },
        dismissButton = { TextButton({ vm.showBulk = false }, Modifier.heightIn(min = 44.dp)) { Text("Vazgeç") } },
    )
}

@Composable fun TutorialDialog(onDone: () -> Unit) {
    val steps = listOf(
        "Bağlantıyı yapıştır" to "Herhangi bir bağlantıyı yapıştır ve Tara'ya dokun. Paylaş menüsünden Down.io'yu seçmen de yeterli.",
        "Seç ve önizle" to "Bulunan medyalara dokunarak önizle. Fotoğraf tam çözünürlükte açılır, video indirmeden oynar. Onay kutusuyla seç.",
        "İndir" to "Kaliteyi seç, İndir'e dokun. Dosyalar İndirilenler klasöründe, geçmişte de görünür.",
    )
    var i by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(steps[i].first, fontWeight = FontWeight.Bold) },
        text = { Text(steps[i].second) },
        confirmButton = { TextButton({ if (i < steps.lastIndex) i++ else onDone() }, Modifier.heightIn(min = 44.dp)) { Text(if (i < steps.lastIndex) "İleri" else "Başla") } },
        dismissButton = { TextButton(onDone, Modifier.heightIn(min = 44.dp)) { Text("Geç") } },
    )
}
