package io.down.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.dnsoverhttps.DnsOverHttps
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.InetAddress
import java.net.URI
import java.util.concurrent.TimeUnit

object Prefs {
    private lateinit var sp: SharedPreferences
    var theme by mutableStateOf("system")
    var haptic by mutableStateOf(true)
    var folder by mutableStateOf("Down.io")
    var quality by mutableStateOf("best")
    var autoPaste by mutableStateOf(true)
    var concurrency by mutableIntStateOf(2)
    var doh by mutableStateOf(false)
    var tutorialSeen by mutableStateOf(false)
    val cookies = mutableStateMapOf<String, String>()

    fun init(c: Context) {
        sp = c.getSharedPreferences("down", 0)
        theme = sp.getString("theme", "system")!!
        haptic = sp.getBoolean("haptic", true)
        folder = sp.getString("folder", "Down.io")!!
        quality = sp.getString("quality", "best")!!
        autoPaste = sp.getBoolean("autoPaste", true)
        concurrency = sp.getInt("conc", 2)
        doh = sp.getBoolean("doh", false)
        tutorialSeen = sp.getBoolean("tut", false)
        runCatching {
            val j = JSONObject(sp.getString("cookies", "{}")!!)
            j.keys().forEach { cookies[it] = j.getString(it) }
        }
    }

    fun save() {
        sp.edit().putString("theme", theme).putBoolean("haptic", haptic).putString("folder", folder.ifBlank { "Down.io" })
            .putString("quality", quality).putBoolean("autoPaste", autoPaste).putInt("conc", concurrency)
            .putBoolean("doh", doh).putBoolean("tut", tutorialSeen)
            .putString("cookies", JSONObject(cookies.toMap()).toString()).apply()
    }

    private fun hostOf(url: String) = runCatching { URI(url).host.orEmpty().lowercase() }.getOrDefault("")
    private fun baseOf(host: String) = host.split('.').takeLast(2).joinToString(".")

    fun saveCookie(url: String, cookie: String) {
        val base = baseOf(hostOf(url))
        if (base.isBlank()) return
        cookies[base] = cookie
        if (base == "x.com") cookies["twitter.com"] = cookie
        if (base == "twitter.com") cookies["x.com"] = cookie
        save()
    }

    private fun entryFor(url: String): Map.Entry<String, String>? {
        val h = hostOf(url)
        return cookies.entries.firstOrNull { h == it.key || h.endsWith("." + it.key) }
    }

    fun cookieHeader(url: String): String? = entryFor(url)?.value

    /** yt-dlp için Netscape formatında çerez dosyası üretir. */
    fun cookieFile(ctx: Context, url: String): File? {
        val e = entryFor(url) ?: return null
        val lines = e.value.split(";").mapNotNull {
            val kv = it.trim().split("=", limit = 2)
            if (kv.size == 2 && kv[0].isNotBlank()) ".${e.key}\tTRUE\t/\tTRUE\t2147483647\t${kv[0]}\t${kv[1]}" else null
        }
        val f = File(ctx.cacheDir, "cookies_${e.key}.txt")
        f.writeText("# Netscape HTTP Cookie File\n" + lines.joinToString("\n") + "\n")
        return f
    }
}

object Store {
    private lateinit var sp: SharedPreferences
    val history = mutableStateListOf<HistoryEntry>()
    val links = mutableStateListOf<String>()

    fun init(c: Context) {
        sp = c.getSharedPreferences("down_store", 0)
        runCatching {
            val a = JSONArray(sp.getString("history", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                history.add(HistoryEntry(o.getString("id"), o.getString("title"), o.getString("type"), o.getString("origin"),
                    o.getString("uri"), o.getLong("size"), o.getLong("time")))
            }
        }
        runCatching {
            val a = JSONArray(sp.getString("links", "[]"))
            for (i in 0 until a.length()) links.add(a.getString(i))
        }
    }

    private fun persist() {
        val a = JSONArray()
        history.forEach {
            a.put(JSONObject().put("id", it.id).put("title", it.title).put("type", it.type).put("origin", it.origin)
                .put("uri", it.uri).put("size", it.size).put("time", it.time))
        }
        sp.edit().putString("history", a.toString()).putString("links", JSONArray(links.toList()).toString()).apply()
    }

    fun addHistory(e: HistoryEntry) { history.add(0, e); persist() }
    fun removeHistory(e: HistoryEntry) { history.remove(e); persist() }
    fun clearHistory() { history.clear(); persist() }
    fun addLink(l: String) { links.remove(l); links.add(0, l); while (links.size > 200) links.removeLast(); persist() }
    fun removeLink(l: String) { links.remove(l); persist() }
}

object Net {
    const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    private val plain = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(40, TimeUnit.SECONDS).followRedirects(true).build()
    private val dohClient by lazy {
        val dns = DnsOverHttps.Builder().client(plain).url("https://cloudflare-dns.com/dns-query".toHttpUrl())
            .bootstrapDnsHosts(InetAddress.getByName("1.1.1.1"), InetAddress.getByName("1.0.0.1")).build()
        plain.newBuilder().dns(dns).build()
    }
    val client: OkHttpClient get() = if (Prefs.doh) dohClient else plain

    fun req(url: String, headers: Map<String, String> = emptyMap(), method: String = "GET", body: RequestBody? = null): Request {
        val b = Request.Builder().url(url).header("User-Agent", UA).method(method, body)
        Prefs.cookieHeader(url)?.let { b.header("Cookie", it) }
        headers.forEach { (k, v) -> b.header(k, v) }
        return b.build()
    }

    fun get(url: String, headers: Map<String, String> = emptyMap()): String =
        client.newCall(req(url, headers)).execute().use { r ->
            val b = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IOException("HTTP ${r.code} ${b.take(160)}")
            b
        }

    fun post(url: String, json: String, headers: Map<String, String> = emptyMap()): String =
        client.newCall(req(url, headers, "POST", json.toRequestBody("application/json".toMediaTypeOrNull()))).execute().use { r ->
            val b = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IOException("HTTP ${r.code} ${b.take(160)}")
            b
        }

    fun head(url: String, headers: Map<String, String> = emptyMap()): Pair<Long?, String?> = runCatching {
        client.newCall(req(url, headers, "HEAD")).execute().use { r ->
            r.header("Content-Length")?.toLongOrNull() to r.header("Content-Type")
        }
    }.getOrDefault(null to null)
}
