package io.down.app

import android.webkit.MimeTypeMap
import androidx.compose.runtime.*
import java.util.Locale
import java.util.UUID

enum class MType(val label: String) { VIDEO("Video"), IMAGE("Fotoğraf"), AUDIO("Ses"), DOC("Belge"), OTHER("Diğer") }
enum class DS { Queued, Running, Done, Failed, Canceled }

data class Media(
    val id: String,
    val title: String,
    val type: MType,
    val ext: String,
    val size: Long?,
    val thumb: String?,
    val sourceUrl: String,      // direct=true ise dosya adresi, değilse yt-dlp'ye verilecek sayfa adresi
    val direct: Boolean,
    val previewUrl: String?,    // indirmeden oynatma / tam çözünürlük görüntüleme adresi
    val headers: Map<String, String> = emptyMap(),
    val origin: String,         // kullanıcının girdiği bağlantı
)

data class HistoryEntry(
    val id: String, val title: String, val type: String, val origin: String,
    val uri: String, val size: Long, val time: Long,
)

class DownloadState(val item: Media) {
    var status by mutableStateOf(DS.Queued)
    var progress by mutableFloatStateOf(0f)
    var error by mutableStateOf<String?>(null)
    var pid: String? = null
    var job: kotlinx.coroutines.Job? = null
}

private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "avif")
private val VID = setOf("mp4", "webm", "mov", "mkv", "avi", "m4v", "3gp", "ts", "m3u8", "flv")
private val AUD = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus")
private val DOCS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "csv", "rtf")

fun typeOf(ext: String): MType = when (ext.lowercase()) {
    in IMG -> MType.IMAGE; in VID -> MType.VIDEO; in AUD -> MType.AUDIO; in DOCS -> MType.DOC; else -> MType.OTHER
}
fun extOf(name: String) = name.substringAfterLast('.', "").lowercase().take(5)
fun uid(s: String): String = UUID.nameUUIDFromBytes(s.toByteArray()).toString()
fun mimeOf(name: String): String =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(extOf(name)) ?: "application/octet-stream"

fun fmtSize(b: Long?): String {
    if (b == null || b <= 0) return "—"
    val u = arrayOf("B", "KB", "MB", "GB"); var v = b.toDouble(); var i = 0
    while (v >= 1024 && i < 3) { v /= 1024; i++ }
    return String.format(Locale.US, if (i == 0) "%.0f %s" else "%.1f %s", v, u[i])
}
