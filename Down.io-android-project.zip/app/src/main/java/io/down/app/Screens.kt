package io.down.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.imageLoader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun openEntry(ctx: Context, e: HistoryEntry) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(e.uri), mimeOf(e.title))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (t: Exception) { toast(ctx, "Dosya açılamadı. Silinmiş olabilir.") }
}

// ───────────── Geçmiş ─────────────
@Composable fun HistoryScreen(vm: AppVM) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val sub = MaterialTheme.colorScheme.onSurfaceVariant
    var seg by remember { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    val df = remember { SimpleDateFormat("d MMM yyyy HH:mm", Locale("tr")) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { LargeTitle("Geçmiş") }
        item { PillRow(listOf("0" to "İndirilenler", "1" to "Bağlantılar"), seg.toString()) { seg = it.toInt() } }
        if (seg == 0) {
            if (Store.history.isEmpty()) item { Text("Henüz indirme yok.", color = sub, modifier = Modifier.padding(20.dp)) }
            else item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.End) {
                    TextButton({ confirm = true }, Modifier.heightIn(min = 44.dp)) { Text("Tümünü sil", color = MaterialTheme.colorScheme.error) }
                }
            }
            items(Store.history.toList(), key = { it.id }) { e ->
                Glass(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(e.title, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${e.type} · ${fmtSize(e.size)} · ${df.format(Date(e.time))}", fontSize = 13.sp, color = sub)
                        Spacer(Modifier.height(6.dp))
                        SelectionContainer { Text(e.origin, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, maxLines = 3) }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton({ openEntry(ctx, e) }, Modifier.heightIn(min = 44.dp)) { Text("Aç") }
                            TextButton({ clip.setText(AnnotatedString(e.origin)); toast(ctx, "Bağlantı kopyalandı") }, Modifier.heightIn(min = 44.dp)) { Text("Bağlantıyı kopyala") }
                            Spacer(Modifier.weight(1f))
                            IconButton({ Store.removeHistory(e) }) { Icon(Icons.Rounded.Delete, "Sil", tint = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        } else {
            if (Store.links.isEmpty()) item { Text("Henüz bağlantı yok.", color = sub, modifier = Modifier.padding(20.dp)) }
            items(Store.links.toList(), key = { it }) { l ->
                Glass(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        SelectionContainer { Text(l, fontSize = 15.sp, maxLines = 3, overflow = TextOverflow.Ellipsis) }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton({ clip.setText(AnnotatedString(l)); toast(ctx, "Bağlantı kopyalandı") }, Modifier.heightIn(min = 44.dp)) { Text("Kopyala") }
                            TextButton({ vm.link = l; vm.tab = 0; vm.scan(listOf(l)) }, Modifier.heightIn(min = 44.dp)) { Text("Tekrar tara") }
                            Spacer(Modifier.weight(1f))
                            IconButton({ Store.removeLink(l) }) { Icon(Icons.Rounded.Delete, "Sil", tint = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Tüm kayıtlar silinsin mi?", fontWeight = FontWeight.Bold) },
        text = { Text("Yalnızca geçmiş kayıtları silinir. İndirilen dosyalar yerinde kalır.") },
        confirmButton = { TextButton({ Store.clearHistory(); confirm = false }, Modifier.heightIn(min = 44.dp)) { Text("Sil", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton({ confirm = false }, Modifier.heightIn(min = 44.dp)) { Text("Vazgeç") } },
    )
}

// ───────────── Ayarlar ─────────────
@Composable private fun Group(title: String, content: @Composable ColumnScope.() -> Unit) {
    SmallLabel(title.uppercase())
    Glass(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) { Column(Modifier.padding(vertical = 8.dp), content = content) }
}

@Composable private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 17.sp)
            Text(sub, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = Blue))
    }
}

@Composable private fun RowLabel(t: String) = Text(t, fontSize = 17.sp, modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 6.dp))

@Composable fun SettingsScreen(vm: AppVM) {
    val ctx = LocalContext.current
    var login by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { LargeTitle("Ayarlar") }
        item {
            Group("Genel") {
                RowLabel("Tema")
                PillRow(listOf("system" to "Sistem", "light" to "Açık", "dark" to "Koyu"), Prefs.theme) { Prefs.theme = it; Prefs.save() }
                SwitchRow("Dokunsal geri bildirim", "Dokunuşlarda hafif titreşim", Prefs.haptic) { Prefs.haptic = it; Prefs.save() }
                TextButton({ vm.showTutorial = true }, Modifier.padding(start = 8.dp).heightIn(min = 44.dp)) { Text("Öğreticiyi göster") }
            }
            Group("İndirme") {
                RowLabel("Kayıt klasörü")
                TextField(
                    Prefs.folder, { Prefs.folder = it.filter { c -> c.isLetterOrDigit() || c in " ._-" }; Prefs.save() },
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true, colors = fieldColors(), shape = RoundedCornerShape(14.dp),
                    supportingText = { Text("İndirilenler/${Prefs.folder.ifBlank { "Down.io" }}") },
                )
                RowLabel("Varsayılan kalite")
                PillRow(listOf("best" to "En iyi", "1080" to "1080p", "720" to "720p", "480" to "480p", "audio" to "Yalnız ses"), Prefs.quality) {
                    Prefs.quality = it; vm.quality = it; Prefs.save()
                }
                SwitchRow("Otomatik pano", "Kopyalanan bağlantıyı açılışta yapıştırır", Prefs.autoPaste) { Prefs.autoPaste = it; Prefs.save() }
                RowLabel("Eşzamanlı indirme")
                PillRow((1..5).map { it.toString() to it.toString() }, Prefs.concurrency.toString()) { Prefs.concurrency = it.toInt(); Prefs.save() }
                Spacer(Modifier.height(8.dp))
            }
            Group("Ağ ve erişim") {
                SwitchRow("Engel aşma (DoH)", "DNS sorgularını şifreler. DNS tabanlı engelleri aşar.", Prefs.doh) { Prefs.doh = it; Prefs.save() }
                TextButton({
                    ctx.imageLoader.memoryCache?.clear(); ctx.imageLoader.diskCache?.clear()
                    java.io.File(ctx.cacheDir, "work").deleteRecursively(); toast(ctx, "Önbellek temizlendi")
                }, Modifier.padding(start = 8.dp).heightIn(min = 44.dp)) { Text("Görsel önbelleğini temizle") }
            }
            Group("Oturum (isteğe bağlı)") {
                Text("Özel hesap gerektiren içerikler için siteye giriş yap. Çerezler cihazda saklanır ve yalnızca o siteye gönderilir.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                TextButton({ login = true }, Modifier.padding(start = 8.dp).heightIn(min = 44.dp)) { Text("Hesap girişi yap") }
                Prefs.cookies.keys.sorted().forEach { host ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(host, Modifier.weight(1f))
                        TextButton({ Prefs.cookies.remove(host); Prefs.save() }, Modifier.heightIn(min = 44.dp)) { Text("Sil", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }
    if (login) LoginDialog { login = false }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable fun LoginDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val holder = remember { arrayOfNulls<WebView>(1) }
    val sites = listOf(
        "Instagram" to "https://www.instagram.com/accounts/login/", "X" to "https://x.com/i/flow/login",
        "Facebook" to "https://m.facebook.com/login", "TikTok" to "https://www.tiktok.com/login",
        "YouTube" to "https://accounts.google.com/ServiceLogin?service=youtube", "Yandex" to "https://passport.yandex.com/auth",
    )
    Dialog(onClose, DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClose) { Icon(Icons.Rounded.Close, "Kapat") }
                    Text("Hesap girişi", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Primary("Oturumu kaydet") {
                        val w = holder[0]; val cur = w?.url
                        val c = if (cur != null) CookieManager.getInstance().getCookie(cur) else null
                        if (cur != null && !c.isNullOrBlank()) { Prefs.saveCookie(cur, c); toast(ctx, "Oturum kaydedildi") }
                        else toast(ctx, "Önce giriş yap")
                    }
                }
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(sites) { (n, u) -> Pill(n, false) { holder[0]?.loadUrl(u) } }
                }
                AndroidView(
                    factory = { c ->
                        WebView(c).apply {
                            settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.userAgentString = Net.UA
                            CookieManager.getInstance().setAcceptCookie(true)
                            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                            webViewClient = WebViewClient()
                            loadUrl(sites[0].second); holder[0] = this
                        }
                    },
                    onRelease = { it.destroy(); holder[0] = null },
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                )
            }
        }
    }
}

// ───────────── Hakkında ─────────────
@Composable fun AboutScreen() {
    LazyColumn(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, contentPadding = PaddingValues(24.dp)) {
        item {
            Spacer(Modifier.height(24.dp)); Logo(96); Spacer(Modifier.height(16.dp))
            Text("Down.io", fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp)
            Text("Sürüm 1.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
            Text("Bağlantıyı yapıştır, medyayı bul, önizle, seçip indir. Tarama motoru yt-dlp'dir; GoFile ve Yandex Disk için özel tarayıcılar içerir.",
                textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Text("Yalnızca indirme hakkına sahip olduğun içerikler için kullan.", textAlign = TextAlign.Center,
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
