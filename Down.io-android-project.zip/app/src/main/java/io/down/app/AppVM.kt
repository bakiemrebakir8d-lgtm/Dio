package io.down.app

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

class AppVM(app: Application) : AndroidViewModel(app) {
    var tab by mutableIntStateOf(0)
    var link by mutableStateOf("")
    var password by mutableStateOf("")
    var scanning by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    val items = mutableStateListOf<Media>()
    val selected = mutableStateListOf<String>()
    var filter by mutableStateOf<MType?>(null)
    var sort by mutableStateOf("name")
    var quality by mutableStateOf(Prefs.quality)
    val tasks = mutableStateMapOf<String, DownloadState>()
    var preview by mutableStateOf<Media?>(null)
    var showBulk by mutableStateOf(false)
    var showTutorial by mutableStateOf(!Prefs.tutorialSeen)

    private var scanJob: Job? = null
    private var sem = Semaphore(Prefs.concurrency)
    private var semN = Prefs.concurrency

    fun scan(urls: List<String>) {
        scanJob?.cancel()
        scanning = true; error = null; items.clear(); selected.clear(); filter = null
        scanJob = viewModelScope.launch {
            Engine.init(getApplication())
            val errs = mutableListOf<String>()
            for (u in urls) {
                try {
                    val r = Scanner.scan(u, password)
                    items.addAll(r.filter { x -> items.none { it.id == x.id } })
                    Store.addLink(u.trim())
                } catch (e: CancellationException) { throw e }
                catch (e: Exception) { errs += if (urls.size > 1) "${u.take(40)}: ${e.message}" else (e.message ?: "Tarama başarısız") }
            }
            scanning = false
            if (errs.isNotEmpty()) error = errs.joinToString("\n")
            else if (items.isEmpty()) error = "Medya bulunamadı."
        }
    }

    fun shown(): List<Media> {
        val f = items.filter { filter == null || it.type == filter }
        return when (sort) {
            "size" -> f.sortedByDescending { it.size ?: 0L }
            "type" -> f.sortedBy { it.type.ordinal }
            else -> f.sortedBy { it.title.lowercase() }
        }
    }

    fun downloadSelected() {
        val ctx = getApplication<Application>()
        if (semN != Prefs.concurrency) { sem = Semaphore(Prefs.concurrency); semN = Prefs.concurrency }
        val s = sem
        items.filter { it.id in selected }.forEach { m ->
            val old = tasks[m.id]
            if (old != null && (old.status == DS.Running || old.status == DS.Queued)) return@forEach
            val st = DownloadState(m)
            tasks[m.id] = st
            st.job = viewModelScope.launch { s.withPermit { Downloader.run(ctx, st, quality) } }
            st.job?.invokeOnCompletion { if (st.status == DS.Queued || st.status == DS.Running) st.status = DS.Canceled }
        }
        selected.clear()
    }

    fun cancel(m: Media) {
        tasks[m.id]?.let { Downloader.cancel(it); it.job?.cancel() }
    }
}
