package io.down.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID

object Downloader {
    private fun work(ctx: Context) = File(ctx.cacheDir, "work").apply { mkdirs() }
    private fun safe(s: String) = s.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_").trim().take(100).ifBlank { "dosya" }

    fun cancel(st: DownloadState) {
        st.pid?.let { runCatching { YoutubeDL.getInstance().destroyProcessById(it) } }
    }

    suspend fun run(ctx: Context, st: DownloadState, quality: String) {
        st.status = DS.Running
        try {
            val (file, name) = withContext(Dispatchers.IO) {
                if (st.item.direct) direct(ctx, st) else ytdlp(ctx, st, quality)
            }
            val size = file.length()
            val uri = withContext(Dispatchers.IO) { publish(ctx, file, name).also { file.delete() } }
            st.progress = 1f
            st.status = DS.Done
            Store.addHistory(HistoryEntry(UUID.randomUUID().toString(), name, st.item.type.label, st.item.origin,
                uri.toString(), size.takeIf { it > 0 } ?: (st.item.size ?: 0L), System.currentTimeMillis()))
        } catch (e: CancellationException) {
            st.status = DS.Canceled; throw e
        } catch (e: Throwable) {
            st.status = DS.Failed; st.error = e.message ?: e.javaClass.simpleName
        }
    }

    private suspend fun direct(ctx: Context, st: DownloadState): Pair<File, String> {
        val it = st.item
        var url = it.sourceUrl
        if (url.startsWith("yadisk:")) {
            val (key, path) = url.removePrefix("yadisk:").split("|", limit = 2)
            val b = "https://cloud-api.yandex.net/v1/disk/public/resources/download".toHttpUrl().newBuilder().addQueryParameter("public_key", key)
            if (path.isNotBlank()) b.addQueryParameter("path", path)
            url = JSONObject(Net.get(b.build().toString())).getString("href")
        }
        val out = File(work(ctx), UUID.randomUUID().toString() + ".tmp")
        Net.client.newCall(Net.req(url, it.headers)).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val body = r.body ?: throw IOException("Boş yanıt")
            val total = body.contentLength()
            body.byteStream().use { inp ->
                out.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024); var read = 0L
                    while (true) {
                        val n = inp.read(buf); if (n < 0) break
                        o.write(buf, 0, n); read += n
                        if (total > 0) st.progress = read / total.toFloat()
                        currentCoroutineContext().ensureActive()
                    }
                }
            }
        }
        val name = if (extOf(it.title).isBlank() && it.ext.isNotBlank()) "${safe(it.title)}.${it.ext}" else safe(it.title)
        return out to name
    }

    private fun ytdlp(ctx: Context, st: DownloadState, quality: String): Pair<File, String> {
        val it = st.item
        val id = UUID.randomUUID().toString()
        val dir = work(ctx)
        val r = YoutubeDLRequest(it.sourceUrl)
        r.addOption("-o", "${dir.absolutePath}/$id.%(ext)s")
        r.addOption("--no-playlist"); r.addOption("--no-mtime"); r.addOption("-N", "4")
        Prefs.cookieFile(ctx, it.sourceUrl)?.let { f -> r.addOption("--cookies", f.absolutePath) }
        var ext = it.ext
        val audioOnly = it.type == MType.AUDIO || (it.type == MType.VIDEO && quality == "audio")
        when {
            audioOnly -> { r.addOption("-x"); r.addOption("--audio-format", "mp3"); ext = "mp3" }
            it.type == MType.VIDEO -> {
                val f = when (quality) {
                    "best" -> "bv*+ba/b"
                    else -> "bv*[height<=$quality]+ba/b[height<=$quality]/b"
                }
                r.addOption("-f", f); r.addOption("--merge-output-format", "mp4")
            }
        }
        st.pid = id
        YoutubeDL.getInstance().execute(r, id) { p, _, _ -> st.progress = (p / 100f).coerceIn(0f, 1f) }
        val file = dir.listFiles { f -> f.name.startsWith(id) && !f.name.endsWith(".part") && !f.name.endsWith(".ytdl") }
            ?.maxByOrNull { f -> f.length() } ?: throw IOException("Dosya oluşmadı")
        return file to "${safe(it.title)}.${file.extension.ifBlank { ext }}"
    }

    private fun publish(ctx: Context, file: File, name: String): Uri {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mimeOf(name))
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/${Prefs.folder.ifBlank { "Down.io" }}")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val res = ctx.contentResolver
        val uri = res.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IOException("Kayıt klasörü açılamadı")
        res.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
        res.update(uri, v, null, null)
        return uri
    }
}
