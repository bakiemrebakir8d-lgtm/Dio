package io.down.app

import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.json.JSONObject
import java.io.IOException
import java.net.URI
import java.net.URLDecoder
import java.security.MessageDigest

class ScanException(msg: String) : Exception(msg)

private fun JSONObject.str(k: String): String? = if (isNull(k)) null else optString(k).ifBlank { null }

object Scanner {
    suspend fun scan(raw: String, password: String?): List<Media> = withContext(Dispatchers.IO) {
        val url = raw.trim().let { if ("://" in it) it else "https://$it" }
        val host = runCatching { URI(url).host.orEmpty().lowercase() }.getOrDefault("")
        val errs = mutableListOf<String>()

        suspend fun attempt(block: suspend () -> List<Media>): List<Media>? = try {
            block().ifEmpty { null }
        } catch (e: ScanException) { throw e }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { errs += e.message.orEmpty().take(300); null }

        if (host.contains("yandex") || host.endsWith("yadi.sk")) attempt { yandex(url) }?.let { return@withContext it }
        if (host.endsWith("gofile.io")) attempt { gofile(url, password) }?.let { return@withContext it }
        if (typeOf(extOf(url.substringBefore('?'))) != MType.OTHER) attempt { listOf(direct(url, emptyMap(), url)) }?.let { return@withContext it }
        if (!Engine.ready) errs += "yt-dlp motoru hazır değil: ${Engine.error ?: "başlatılamadı"}"
        else attempt { ytdlp(url, password) }?.let { return@withContext it }
        attempt { scrape(url) }?.let { return@withContext it }
        throw ScanException(errs.lastOrNull() ?: "Bu bağlantıda medya bulunamadı.")
    }

    // ---------- doğrudan dosya ----------
    private fun direct(url: String, headers: Map<String, String>, origin: String): Media {
        val (size, ct) = Net.head(url, headers)
        val path = runCatching { URI(url).path }.getOrNull().orEmpty()
        var name = runCatching { URLDecoder.decode(path.substringAfterLast('/'), "UTF-8") }.getOrDefault("").ifBlank { "dosya" }
        var ext = extOf(name)
        if (ext.isBlank()) {
            ext = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(ct?.substringBefore(';')?.trim()) ?: ""
            if (ext.isNotBlank()) name = "$name.$ext"
        }
        val t = typeOf(ext)
        val playable = t == MType.VIDEO || t == MType.IMAGE || t == MType.AUDIO
        return Media(uid(url), name, t, ext, size, if (t == MType.IMAGE) url else null, url, true,
            if (playable) url else null, headers, origin)
    }

    // ---------- yt-dlp ----------
    private fun ytdlp(url: String, password: String?): List<Media> {
        val r = YoutubeDLRequest(url)
        r.addOption("-J"); r.addOption("--no-warnings"); r.addOption("--playlist-end", "60"); r.addOption("--socket-timeout", "20")
        Prefs.cookieFile(appCtx, url)?.let { r.addOption("--cookies", it.absolutePath) }
        if (!password.isNullOrBlank()) r.addOption("--video-password", password)
        val out = YoutubeDL.getInstance().execute(r).out
        val i = out.indexOf('{')
        if (i < 0) throw IOException("yt-dlp çıktı üretmedi")
        val acc = mutableListOf<Media>()
        collect(JSONObject(out.substring(i)), url, acc)
        return acc.distinctBy { it.id }
    }

    lateinit var appCtx: android.content.Context

    private fun collect(j: JSONObject, origin: String, acc: MutableList<Media>) {
        val entries = j.optJSONArray("entries")
        if (entries != null) {
            for (i in 0 until entries.length()) entries.optJSONObject(i)?.let { collect(it, origin, acc) }
            return
        }
        acc += toMedia(j, origin)
    }

    private fun toMedia(j: JSONObject, origin: String): Media {
        val fm = j.optJSONArray("formats")
        var prog: JSONObject? = null
        var bestV: JSONObject? = null
        var maxSize = 0L
        if (fm != null) for (i in 0 until fm.length()) {
            val f = fm.optJSONObject(i) ?: continue
            val v = f.str("vcodec") ?: "none"; val a = f.str("acodec") ?: "none"
            val h = f.optInt("height")
            maxSize = maxOf(maxSize, f.optLong("filesize"), f.optLong("filesize_approx"))
            if (f.str("url") == null || f.str("protocol")?.contains("dash") == true) continue
            if (v != "none" && (bestV == null || h >= bestV.optInt("height"))) bestV = f
            if (v != "none" && a != "none" && (prog == null || h >= prog.optInt("height"))) prog = f
        }
        val ext = j.str("ext") ?: "mp4"
        val vc = j.str("vcodec"); val ac = j.str("acodec")
        var t = typeOf(ext)
        if (t == MType.OTHER && fm != null) t = MType.VIDEO
        if (t == MType.VIDEO && vc == "none" && ac != null && ac != "none") t = MType.AUDIO
        val size = listOf(j.optLong("filesize"), j.optLong("filesize_approx"), maxSize).firstOrNull { it > 0 }
        val top = j.str("url")
        val chosen = prog ?: bestV
        val preview = when (t) {
            MType.IMAGE -> top ?: j.str("thumbnail")
            MType.VIDEO, MType.AUDIO -> chosen?.str("url") ?: top
            else -> null
        }
        val hdrObj = chosen?.optJSONObject("http_headers") ?: j.optJSONObject("http_headers")
        val hdrs = hdrObj?.keys()?.asSequence()?.associateWith { hdrObj.getString(it) } ?: emptyMap()
        val title = j.str("title") ?: j.str("id") ?: "medya"
        val src = j.str("webpage_url") ?: j.str("original_url") ?: origin
        val thumb = j.str("thumbnail") ?: if (t == MType.IMAGE) top else null
        return Media(uid(src + title + (j.str("id") ?: "")), title, t, ext, size, thumb, src, false, preview, hdrs, origin)
    }

    // ---------- GoFile ----------
    private fun sha256(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun gofile(url: String, password: String?): List<Media> {
        val id = url.substringAfter("/d/", "").substringBefore('?').substringBefore('/')
        if (id.isBlank()) throw ScanException("GoFile bağlantısı tanınmadı.")
        val tok = JSONObject(Net.post("https://api.gofile.io/accounts", "{}")).getJSONObject("data").getString("token")
        val wt = runCatching {
            Regex("appdata\\.wt\\s*=\\s*\"([^\"]+)\"").find(Net.get("https://gofile.io/dist/js/global.js"))?.groupValues?.get(1)
        }.getOrNull() ?: "4fd6sg89d7s6"
        val auth = mapOf("Authorization" to "Bearer $tok")
        val fileHdr = mapOf("Cookie" to "accountToken=$tok")
        val out = mutableListOf<Media>()
        val needPw = "Klasör şifreli. Şifreyi girip tekrar tara."

        fun walk(cid: String, depth: Int) {
            var u = "https://api.gofile.io/contents/$cid?wt=$wt&contentFilter=&page=1&pageSize=1000&sortField=name&sortDirection=1"
            if (!password.isNullOrBlank()) u += "&password=" + sha256(password)
            val j = JSONObject(Net.get(u, auth))
            val st = j.optString("status")
            if (st != "ok") { if (st.contains("password", true)) throw ScanException(needPw); throw IOException("GoFile: $st") }
            val d = j.getJSONObject("data")
            when (d.optString("passwordStatus", "passwordOk")) {
                "passwordRequired" -> throw ScanException(needPw)
                "passwordWrong" -> throw ScanException("GoFile şifresi yanlış.")
            }
            val ch = d.optJSONObject("children") ?: return
            ch.keys().forEach { k ->
                val c = ch.getJSONObject(k)
                if (c.optString("type") == "folder") {
                    if (depth < 4) walk(c.optString("id", k), depth + 1)
                } else {
                    val link = c.optString("link")
                    if (link.isNotBlank()) {
                        val name = c.optString("name"); val ext = extOf(name); val t = typeOf(ext)
                        val playable = t == MType.VIDEO || t == MType.IMAGE || t == MType.AUDIO
                        out += Media(uid(link), name, t, ext, c.optLong("size").takeIf { it > 0 },
                            c.str("thumbnail") ?: if (t == MType.IMAGE) link else null,
                            link, true, if (playable) link else null, fileHdr, url)
                    }
                }
            }
        }
        walk(id, 0)
        return out
    }

    // ---------- Yandex Disk ----------
    private fun yandex(key: String): List<Media> {
        val out = mutableListOf<Media>()
        fun add(o: JSONObject) {
            val name = o.optString("name"); val ext = extOf(name)
            val t = when (o.optString("media_type")) {
                "image" -> MType.IMAGE; "video" -> MType.VIDEO; "audio" -> MType.AUDIO; "document" -> MType.DOC
                else -> typeOf(ext)
            }
            val file = o.str("file")
            val src = file ?: "yadisk:$key|${o.optString("path")}"
            val playable = t == MType.VIDEO || t == MType.IMAGE || t == MType.AUDIO
            out += Media(uid(src + name), name, t, ext, o.optLong("size").takeIf { it > 0 }, o.str("preview"), src, true,
                if (file != null && playable) file else null, emptyMap(), key)
        }
        fun walk(path: String?, depth: Int) {
            var offset = 0
            while (true) {
                val b = "https://cloud-api.yandex.net/v1/disk/public/resources".toHttpUrl().newBuilder()
                    .addQueryParameter("public_key", key).addQueryParameter("limit", "200").addQueryParameter("offset", "$offset")
                path?.let { b.addQueryParameter("path", it) }
                val j = JSONObject(Net.get(b.build().toString()))
                if (j.optString("type") == "file") { add(j); return }
                val emb = j.optJSONObject("_embedded") ?: return
                val items = emb.optJSONArray("items") ?: return
                for (i in 0 until items.length()) {
                    val o = items.getJSONObject(i)
                    if (o.optString("type") == "dir") { if (depth < 4) walk(o.optString("path"), depth + 1) } else add(o)
                }
                offset += items.length()
                if (items.length() == 0 || offset >= emb.optInt("total")) break
            }
        }
        walk(null, 0)
        return out
    }

    // ---------- genel sayfa taraması ----------
    private suspend fun scrape(url: String): List<Media> {
        val html = Net.get(url)
        val base = URI(url)
        val ext = "jpg|jpeg|png|gif|webp|avif|mp4|webm|mov|m4v|mkv|mp3|m4a|wav|flac|ogg|pdf|docx?|xlsx?|pptx?|zip|rar|7z"
        val a = Regex("""(?:src|href|data-src|poster|content)\s*=\s*["']([^"']+?\.(?:$ext)(?:\?[^"']*)?)["']""", RegexOption.IGNORE_CASE)
        val og = Regex("""<meta[^>]+property=["']og:(?:image|video)(?::url|:secure_url)?["'][^>]+content=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
        val found = linkedSetOf<String>()
        (a.findAll(html) + og.findAll(html)).forEach { m ->
            val u = runCatching { base.resolve(m.groupValues[1].replace("&amp;", "&")).toString() }.getOrNull()
            if (u != null && u.startsWith("http")) found += u
        }
        val sem = Semaphore(8)
        val hdr = mapOf("Referer" to url)
        val list = coroutineScope {
            found.take(200).map { u -> async { sem.withPermit { runCatching { direct(u, hdr, url) }.getOrNull() } } }.awaitAll()
        }
        return list.filterNotNull().filter { it.size == null || it.size > 3000 }.distinctBy { it.id }
    }
}
