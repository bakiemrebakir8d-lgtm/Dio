package io.down.app

import android.app.Application
import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Store.init(this)
        Scanner.appCtx = this
    }
}

object Engine {
    @Volatile var ready = false
    @Volatile var error: String? = null
    private val mutex = Mutex()

    suspend fun init(ctx: Context) {
        if (ready) return
        mutex.withLock {
            if (ready) return
            withContext(Dispatchers.IO) {
                try {
                    YoutubeDL.getInstance().init(ctx.applicationContext)
                    FFmpeg.getInstance().init(ctx.applicationContext)
                    ready = true
                } catch (t: Throwable) { error = t.message }
            }
        }
    }
}
